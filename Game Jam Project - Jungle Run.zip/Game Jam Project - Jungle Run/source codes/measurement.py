num_of_blocks_vertically = 11
block_size = 64

game_screen_width = 1200
game_screen_height = num_of_blocks_vertically * block_size
